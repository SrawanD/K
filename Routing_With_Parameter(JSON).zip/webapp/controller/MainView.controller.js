sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.routing.controller.MainView", {

		onInit: function() {

			var oModel = new sap.ui.model.json.JSONModel();
			oModel.loadData("model/Data.json");
			sap.ui.getCore().setModel(oModel);
			var oTable = this.getView().byId("EmployeeDetails");
			oTable.setModel(oModel, "oModelData");

		},

		onPressItemDetail: function(oEvent) {

			var that = this;

			var EmployeeID = oEvent.getSource().getBindingContext("oModelData").getObject().EmployeeId;
			var EmployeeName = oEvent.getSource().getBindingContext("oModelData").getObject().EmployeeName;
			var Designation = oEvent.getSource().getBindingContext("oModelData").getObject().Designation;
			var PhoneNumber = oEvent.getSource().getBindingContext("oModelData").getObject().PhoneNo;

			// this.getRouter().navTo("Detail", {

			// EmployeeId: EmployeeID,
			// EmployeeName: EmployeeName,
			// Designation: Designation,
			// PhoneNo: PhoneNumber

			// });

			sap.ui.core.UIComponent.getRouterFor(this).navTo("DetailView", {
				EmployeeId: EmployeeID,
				EmployeeName: EmployeeName,
				Designation: Designation,
				PhoneNo: PhoneNumber

			});
		}

	});

});