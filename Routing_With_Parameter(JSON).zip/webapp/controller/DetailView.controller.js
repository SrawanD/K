var aTableData = [];
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.routing.controller.DetailView", {

		onInit: function() {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("DetailView").attachMatched(this._onRouteMatched, this);

		},

		_onRouteMatched: function(oEvent) {
			
			// var oArgs = oEvent.getParameter("arguments");
			// console.log(oArgs);
			// aTableData.push(oArgs);
			// console.log(aTableData);
			// var oTable = this.getView().byId("detailsTable");
			// oTable.setModel(new sap.ui.model.json.JSONModel({
			// 	"oModelData": aTableData
			// }));
			
			// var oArgs = oEvent.getParameter("arguments");
			// console.log(oArgs);
			// this.byId("EmpId").setText(oArgs.EmployeeId);
			// this.byId("EmpName").setText(oArgs.EmployeeName);
			// this.byId("Desg").setText(oArgs.Designation);
			// this.byId("Phone").setText(oArgs.PhoneNo);
			

			var oArgs = oEvent.getParameter("arguments");
			console.log(oArgs);
			this.byId("EmpId").setTitle(oArgs.EmployeeId);
			this.byId("EmpName").setText(oArgs.EmployeeName);
			this.byId("Desg").setText(oArgs.Designation);
			this.byId("Phone").setText(oArgs.PhoneNo);
			

		},

		onNavBack: function() {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("MainView");

		}

	});

});